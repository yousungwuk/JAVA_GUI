package TeamProject;

import java.awt.*;

public class Poly_Triangle extends Inter_Poly{
	private int[] X;
	private int[] Y;
	@Override
	public void draw(Graphics2D g) {
		if (Done_set) {
			BasicStroke lineType;
			lineType = new BasicStroke(
					lineType_width,lineType_cap,
					lineType_join,lineType_miterlimit,
					lineType_dash,lineType_dash_phase);
			g.setStroke(lineType);
			g.setColor(p_Color);
			if (regular) {
				diameter = Math.min(Math.abs(rEndPoint.x - rStartPoint.x), Math.abs(rEndPoint.y - rStartPoint.y));
				X = new int[]{rStartPoint.x, rStartPoint.x+diameter/2, rStartPoint.x+diameter};
				Y = new int[]{rStartPoint.y+diameter, rStartPoint.y, rStartPoint.y+diameter};
				if (fill) {
					g.fillPolygon(X, Y, 3);
				}
				else {
					g.drawPolygon(X, Y, 3);
				}
			}
			else {
				X = new int[]{rStartPoint.x, rStartPoint.x+width/2, rEndPoint.x};
				Y = new int[]{rEndPoint.y, rStartPoint.y, rEndPoint.y};
				if (fill) {
					g.fillPolygon(X, Y, 3);
				}
				else {
					g.drawPolygon(X, Y, 3);
				} 
			}
			return;
		}
		BasicStroke lineType;
		lineType = new BasicStroke(
				lineType_width,lineType_cap,
				lineType_join,lineType_miterlimit,
				lineType_dash,lineType_dash_phase);
		g.setStroke(lineType);
		g.setColor(p_Color);
		//
		if (regular) {
			diameter = Math.min(Math.abs(EndPoint.x - StartPoint.x), Math.abs(EndPoint.y - StartPoint.y));
			width = diameter;
			height = diameter;
			int xDiameter = diameter;
			int yDiameter = diameter;
			if (EndPoint.x < StartPoint.x) xDiameter *= -1;
			if (EndPoint.y < StartPoint.y) yDiameter *= -1;
			rStartPoint = new Point(Math.min(StartPoint.x, StartPoint.x+xDiameter), Math.min(StartPoint.y, StartPoint.y+yDiameter));
			rEndPoint = new Point(rStartPoint.x+diameter, rStartPoint.y+diameter);
			X = new int[]{rStartPoint.x, rStartPoint.x+diameter/2, rStartPoint.x+diameter};
			Y = new int[]{rStartPoint.y+diameter, rStartPoint.y, rStartPoint.y+diameter};
			
			if (fill) {
				g.fillPolygon(X, Y, 3);
			}
			else {
				g.drawPolygon(X, Y, 3);
			}
		}
		else {
			width = Math.abs(EndPoint.x - StartPoint.x);
			height = Math.abs(EndPoint.y - StartPoint.y);
			rStartPoint = new Point(Math.min(StartPoint.x, EndPoint.x), Math.min(StartPoint.y, EndPoint.y));
			rEndPoint = new Point(rStartPoint.x+width,rStartPoint.y+height);
			X = new int[]{rStartPoint.x, rStartPoint.x+width/2, rEndPoint.x};
			Y = new int[]{rEndPoint.y, rStartPoint.y, rEndPoint.y};
			
			if (fill) {
				g.fillPolygon(X, Y, 3);
			}
			else {
				g.drawPolygon(X, Y, 3);
			} 
		}
	}
}
