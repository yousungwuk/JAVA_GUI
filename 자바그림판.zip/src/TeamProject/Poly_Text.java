package TeamProject;


import java.awt.*;

public class Poly_Text extends Inter_Poly{
	private String text;
	private int fontSize = 10;
	private String fontType = "Serif";
	private boolean bold = false;
	private boolean italic =false;
	private Font font;
	
	

	private void setFont() {
		if (bold && italic) font = new Font(fontType,Font.BOLD+Font.ITALIC,fontSize);
		else if (bold) font = new Font(fontType,Font.BOLD,fontSize);
		else if (italic) font = new Font(fontType,Font.ITALIC,fontSize);
		else font = new Font(fontType,Font.PLAIN,fontSize);
	}
	public Poly_Text(String t) {
		text = t;
	}
	
	@Override
	public boolean contains(Point p) {
		if (rStartPoint.x <= p.x && rStartPoint.y-fontSize <= p.y &&
				rEndPoint.x >= p.x && rEndPoint.y-fontSize >= p.y) {
			return true;
		}
		return false;
	}
	@Override
	public void drawBound(Graphics2D g2d,Color c) {
		g2d.setColor(c);
    	final float dash[] = {2, 2};
    	g2d.setStroke(new BasicStroke(2,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,0,dash,0));
    	g2d.drawRect(rStartPoint.x, rStartPoint.y-fontSize, width, height);
	}
	public void setFontType(String ft) {
		fontType = ft;
	}
	public void setBold_Italic(boolean btf, boolean itf) {
		bold = btf;
		italic = itf;
	}
	@Override
	public void draw(Graphics2D g) {
		g.setColor(p_Color);
		fontSize = (int)lineType_width * 10;
		width = (text.length()*fontSize)/2;
		height = fontSize;
		rStartPoint = new Point(StartPoint.x, StartPoint.y);
		rEndPoint = new Point(rStartPoint.x+width,rStartPoint.y+height);
		setFont();
		g.setFont(font);		
		g.drawString(text, rStartPoint.x, rStartPoint.y);
	}
}
