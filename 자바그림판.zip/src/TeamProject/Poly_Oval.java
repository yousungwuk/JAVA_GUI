package TeamProject;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class Poly_Oval extends Inter_Poly {
	@Override
	public void draw(Graphics2D g) {
		if (Done_set) {
			BasicStroke lineType;
			lineType = new BasicStroke(lineType_width, lineType_cap, lineType_join, lineType_miterlimit, lineType_dash,
					lineType_dash_phase);
			g.setStroke(lineType);
			g.setColor(p_Color);
			if (regular) {
				if (fill) {
					g.fillOval(rStartPoint.x, rStartPoint.y, diameter, diameter);
				} else {
					g.drawOval(rStartPoint.x, rStartPoint.y, diameter, diameter);
				}
			} else {
				if (fill) {
					g.fillOval(rStartPoint.x, rStartPoint.y, width, height);
				} else {
					g.drawOval(rStartPoint.x, rStartPoint.y, width, height);
				}
			}
			return;
		}
		lineType_cap = BasicStroke.CAP_ROUND;
		lineType_join = BasicStroke.JOIN_ROUND;
		BasicStroke lineType;
		lineType = new BasicStroke(lineType_width, lineType_cap, lineType_join, lineType_miterlimit, lineType_dash,
				lineType_dash_phase);
		g.setStroke(lineType);
		g.setColor(p_Color);
		//
		if (regular) {
			diameter = Math.min(Math.abs(EndPoint.x - StartPoint.x), Math.abs(EndPoint.y - StartPoint.y));
			width = diameter;
			height = diameter;
			int xDiameter = diameter;
			int yDiameter = diameter;
			if (EndPoint.x < StartPoint.x)
				xDiameter *= -1;
			if (EndPoint.y < StartPoint.y)
				yDiameter *= -1;
			rStartPoint = new Point(Math.min(StartPoint.x, StartPoint.x + xDiameter), Math.min(StartPoint.y, StartPoint.y + yDiameter));
			rEndPoint = new Point(rStartPoint.x + diameter, rStartPoint.y + diameter);

			if (fill) {
				g.fillOval(rStartPoint.x, rStartPoint.y, diameter, diameter);
			} else {
				g.drawOval(rStartPoint.x, rStartPoint.y, diameter, diameter);
			}
		} else {
			width = Math.abs(EndPoint.x - StartPoint.x);
			height = Math.abs(EndPoint.y - StartPoint.y);
			rStartPoint = new Point(Math.min(StartPoint.x, EndPoint.x), Math.min(StartPoint.y, EndPoint.y));
			rEndPoint = new Point(rStartPoint.x + width, rStartPoint.y + height);
			if (fill) {
				g.fillOval(rStartPoint.x, rStartPoint.y, width, height);
			} else {
				g.drawOval(rStartPoint.x, rStartPoint.y, width, height);
			}
		}
	}
}
