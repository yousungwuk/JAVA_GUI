package TeamProject;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class Poly_Img extends Inter_Poly{
	private String filePath;
	
	public Poly_Img(String path) {
		filePath = path;
		Image img = new ImageIcon(filePath).getImage();
		rStartPoint = new Point(0,0);
		rEndPoint = new Point(img.getWidth(null),img.getHeight(null));
		width = img.getWidth(null);
		height = img.getHeight(null);
	}
	
   @Override
   public void draw(Graphics2D g) {
	   Image img = new ImageIcon(filePath).getImage();
	   g.drawImage(img,rStartPoint.x,rStartPoint.y,width,height,null);
   }
}
