package TeamProject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.*;
import java.util.ArrayList;
import java.util.List;

public class PaintPanel extends JPanel {
   private Color selectColor = Color.BLACK;
   private int poly = 5;//����Ÿ��
   private List<Inter_Poly> arrayPoly = new ArrayList<Inter_Poly>();//�ƹ����ϱ� �ڽ��� �ٴ������־ �̰ɷ� �������
   private Inter_Poly currentPoly;
   private Inter_Poly preSelectPoly;//���õǱ����� ������� �̸�����Ų�ž� 
   private Inter_Poly selectPoly = null;
   private float line_width = 1;
   private boolean fill; // ���� ä���
   private boolean regular; // ����
   private boolean mouse_on_poly;
   private boolean clicked_poly;
   private boolean font_Bold;
   private boolean font_Italic;
   private String moveType = "";
   private String fontType = "";

   public PaintPanel() {
      setBackground(Color.WHITE); // ���� ����
      addMouseListener(new MyMouseListener());
      addMouseMotionListener(new MyMouseMotionListener());
      setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
   }

   private class MyMouseListener extends MouseAdapter {
      @Override
      public void mousePressed(MouseEvent e) {
         Point p = e.getPoint();
         switch (poly) {
         case 0:
            currentPoly = new Poly_Line();
            setCurrentPoly(p);
            break;
         case 1:
            currentPoly = new Poly_Triangle();
            setCurrentPoly(p);
            break;
         case 2:
            currentPoly = new Poly_RightTri();
            setCurrentPoly(p);
            break;
         case 3:
            currentPoly = new Poly_Rect();
            setCurrentPoly(p);
            break;
         case 4:
            currentPoly = new Poly_Oval();
            setCurrentPoly(p);
            break;
         case 5:
            currentPoly = new Poly_FreeDraw();
            setCurrentPoly(p);
            break;
         case 6:
            if (selectPoly != null) {
               moveType = selectPoly.polyMove(p);
               if (moveType == "move") {
                  setCursor(new Cursor(Cursor.MOVE_CURSOR));
               }
               repaint();
            }
            break;
         case 9:
            currentPoly = new Poly_Star();
            setCurrentPoly(p);
            break;
         case 10:
            break;
            
         }
      }

      @Override
      public void mouseReleased(MouseEvent e) {
         if (currentPoly != null) {
            currentPoly.setEndPoint(e.getPoint());
            currentPoly.setOptimization(true);
            repaint();
         }
         if (selectPoly != null && moveType == "move") {
            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            moveType = "";
         }

      }

      @Override
      public void mouseClicked(MouseEvent e) {
         if (poly == 6) {
            clicked_poly = false;
            if (mouse_on_poly) {
               clicked_poly = true;
               selectPoly = preSelectPoly;
            }
            repaint();
         }
         else if(poly == 10) {
            clicked_poly = false;
            if (mouse_on_poly) {
               clicked_poly = true;
               CopyPoly(preSelectPoly); //CopyPoly �޼���(�г� �޼���) ȣ���Ͽ� ���� ����
            }
            repaint();
         }
         else if (poly == 7) {
            if (clicked_poly) {
               arrayPoly.remove(selectPoly);
               selectPoly = null;
               clicked_poly = false;
            }
            repaint();
         } else if (poly == 8) {
            currentPoly = new Poly_Text(JOptionPane.showInputDialog("Enter Text"));
            arrayPoly.add(currentPoly);
            ((Poly_Text) currentPoly).setFontType(fontType);
            currentPoly.setLineType_width(line_width);
            ((Poly_Text) currentPoly).setBold_Italic(font_Bold, font_Italic);
            currentPoly.setColor(selectColor);
            currentPoly.setStartPoint(e.getPoint());
            currentPoly.setOptimization(true);
            repaint();
         }
      }
   }

   private class MyMouseMotionListener extends MouseMotionAdapter {
      @Override
      public void mouseDragged(MouseEvent e) {
         Point p = e.getPoint();
         if (currentPoly != null) {
            currentPoly.setEndPoint(e.getPoint());
            repaint();
         } 
         else if (poly == 6) {
            if (selectPoly != null) {
               switch (moveType) {
               case "pNW":
                  selectPoly.setRStartPoint(p);
                  selectPoly.rEndPoint_HW();
                  if (p.x > selectPoly.rEndPoint.x)
                     break;
                  if (p.y > selectPoly.rEndPoint.y)
                     break;
                  repaint();
                  break;
               case "pN":
                  selectPoly.setRStartPoint(new Point(selectPoly.getRStartPoint().x, p.y));
                  selectPoly.rEndPoint_HW();
                  if (p.y > selectPoly.rEndPoint.y)
                     break;
                  repaint();
                  break;
               case "pNE":
                  selectPoly.setRStartPoint(new Point(selectPoly.getRStartPoint().x, p.y));
                  selectPoly.setrEndPoint(new Point(p.x, selectPoly.getrEndPoint().y));
                  selectPoly.rEndPoint_HW();
                  if (p.x < selectPoly.rStartPoint.x)
                     break;
                  if (p.y > selectPoly.rEndPoint.y)
                     break;
                  repaint();
                  break;
               case "pE":
                  selectPoly.setrEndPoint(new Point(p.x, selectPoly.getrEndPoint().y));
                  selectPoly.rEndPoint_HW();
                  if (p.x < selectPoly.rStartPoint.x)
                     break;
                  repaint();
                  break;
               case "pSE":
                  selectPoly.setrEndPoint(new Point(p.x, p.y));
                  selectPoly.rEndPoint_HW();
                  if (p.x < selectPoly.rStartPoint.x)
                     break;
                  if (p.y < selectPoly.rStartPoint.y)
                     break;
                  repaint();
                  break;
               case "pS":
                  selectPoly.setrEndPoint(new Point(selectPoly.getrEndPoint().x, p.y));
                  selectPoly.rEndPoint_HW();
                  if (p.y < selectPoly.rStartPoint.y)
                     break;
                  repaint();
                  break;
               case "pSW":
                  selectPoly.setRStartPoint(new Point(p.x, selectPoly.getRStartPoint().y));
                  selectPoly.setrEndPoint(new Point(selectPoly.getrEndPoint().x, p.y));
                  selectPoly.rEndPoint_HW();
                  if (p.x > selectPoly.rEndPoint.x)
                     break;
                  if (p.y < selectPoly.rStartPoint.y)
                     break;
                  repaint();
                  break;
               case "pW":
                  selectPoly.setRStartPoint(new Point(p.x, selectPoly.getRStartPoint().y));
                  selectPoly.rEndPoint_HW();
                  if (p.x > selectPoly.rEndPoint.x)
                     break;
                  repaint();
                  break;
               case "move":
                  int x = p.x - (selectPoly.getWidth() / 2);
                  int y = p.y - (selectPoly.getHeight() / 2);
                  selectPoly.setRStartPoint(new Point(x, y));
                  selectPoly.HW_rEndPoint();
                  repaint();
                  break;
               }
            }
         }
      }

      @Override
      public void mouseMoved(MouseEvent e) {
         if (poly == 6 || poly==10){ //���� ����
            if (selectPoly != null) {
               if (selectPoly.getMoveCursor(e.getPoint()) != Cursor.DEFAULT_CURSOR) {
                  Cursor mouseCursor = new Cursor(selectPoly.getMoveCursor(e.getPoint()));
                  setCursor(mouseCursor);
                  return;
               }
            }
            mouse_on_poly = false;
            preSelectPoly = null;
            for (Inter_Poly i : arrayPoly) {//���ϸ��������׸� �����ȿ� ���콺�� �ִ��� �ֽ�ȭ �����ִ°�
               try {
                  if (i.contains(e.getPoint()) && i.getClass().getName() != "Poly_FreeDraw"
                        && i.getClass().getName() != "Poly_Text") {
                     mouse_on_poly = true;
                     setCursor(new Cursor(Cursor.HAND_CURSOR));
                     preSelectPoly = i;
                  }
               } catch (NullPointerException exception) {
                  // System.err.println("�����Ͱ� �Էµ��� ����");
               }

            }
            if (!mouse_on_poly)
               setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            repaint();
         } else if (poly == 7) {
            clicked_poly = false;
            selectPoly = null;
            for (Inter_Poly i : arrayPoly) {
               try {
                  if (i.contains(e.getPoint())) {
                     clicked_poly = true;
                     setCursor(new Cursor(Cursor.HAND_CURSOR));
                     selectPoly = i;
                  }
               } catch (NullPointerException exception) {
                  // System.err.println("�����Ͱ� �Էµ��� ����");
               }

            }
            if (!clicked_poly)
               setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            repaint();
         }
      }
   }

   private void setCurrentPoly(Point p) {//���� ���õ� ���� ����
      arrayPoly.add(currentPoly);
      currentPoly.setColor(selectColor);
      currentPoly.setLineType_width(line_width);
      currentPoly.setFillRegular(fill, regular);
      currentPoly.setStartPoint(p);
   }
   
   private void CopyPoly(Inter_Poly poly) { //�����ϴ� �Լ�
     Inter_Poly tempPoly = null;
     try {
         tempPoly = (Inter_Poly)poly.clone(); //preSelectPoly�� ���� ����
         arrayPoly.add(tempPoly); //����Ʈ�� �߰�
      } 
     catch (CloneNotSupportedException e) {
         e.printStackTrace();//����ó��
      }
     Point tempPt = tempPoly.getRStartPoint(); //����Ʈ ����
       tempPoly.setRStartPoint(new Point(tempPt.x+10, tempPt.y+10)); //����Ʈ ��ü�� ��� ���� ���簡 �������� �ʾ� ���� ���簡 ��. ���� �� ���� ��ü �������ִ� ������� ��
       tempPoly.HW_rEndPoint(); //ũ�� ����. �̰� �巡�� ��Ʈ�� ���� 'move'�ϴ� ���� ���� �ִ°ǵ� ���� ��ġ ��(rEndPoint), �ʺ���� ����ؼ� �Է����ִ� �޼�����.
     repaint();
   }


   public void paintComponent(Graphics g) {
      super.paintComponent(g);
      Graphics2D g2d = (Graphics2D) g;
      for (Inter_Poly poly : arrayPoly) {
         try {
            poly.draw(g2d);
         } catch (NullPointerException e) {
            // System.err.println("�����Ͱ� �Էµ��� ����");
         }
      }
      if (poly == 6) {
         if (mouse_on_poly) {
            preSelectPoly.drawBound(g2d, Color.yellow);
         }
         if (clicked_poly) {
            selectPoly.drawBound(g2d, Color.BLUE);
            selectPoly.drawSetPoint(g2d);
         }
      }
      if(poly == 10) {
         if (mouse_on_poly) {
            preSelectPoly.drawBound(g2d, Color.green);
         }
      }
      if (poly == 7) {
         if (clicked_poly) {
            selectPoly.drawBound(g2d, Color.RED);
         }
      }
   }

   // �ܺ� ȣ��� �޼���//jframe���� menubar�� �ִ� event�� �Ѱܹޱ� ���ؼ� ���� methods
   public void clearPanel() {
      arrayPoly = new ArrayList<Inter_Poly>();
      preSelectPoly = null;
      selectPoly = null;
      clicked_poly = false;
      mouse_on_poly = false;
      selectColor = Color.BLACK;
      poly = 5;
      line_width = 1;
      setBackground(Color.WHITE);
      setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
      repaint();
   }

   public void setColor(Color C) {
      selectColor = C;
      if (selectPoly != null && poly == 6) {
         selectPoly.setColor(selectColor); 
      }
   }

   public void setPoly(String p) {
      switch (p) {
      case "��":
         poly = 0;
         break;
      case "�ﰢ��":
         poly = 1;
         break;
      case "�����ﰢ��":
         poly = 2;
         break;
      case "�簢��":
         poly = 3;
         break;
      case "��":
         poly = 4;
         break;
      case "������":
         poly = 5;
         break;
      case "���� ����":
         poly = 6;
         currentPoly = null;
         break;
      case "���� ����":
         poly = 7;
         currentPoly = null;
         break;
      case "�ؽ�Ʈ":
         poly = 8;
         break;
      case "��":
         poly = 9;
         break;
      case "���� ����":
         poly = 10;
         break;
      }
      preSelectPoly = null;
      selectPoly = null;
      clicked_poly = false;
      mouse_on_poly = false;
      repaint();
   }

   public void setOption(String p, boolean t) {
      switch (p) {
      case "ä���":
         fill = t;
         if (selectPoly != null && poly == 6) {
            selectPoly.fill = t;
         }
         break;
      case "���ٰ���":
         regular = t;
         break;
      }
   }

   public void setStroke(int s) {
      line_width = s;
   }

   public void setArrayPoly(List<Inter_Poly> arrayP) {
      arrayPoly = arrayP;
   }

   public List<Inter_Poly> getArrayPoly() {
      return arrayPoly;
   }

   public void insertPoly(Inter_Poly poly) {//������ �־��ֱ����ؼ�
      arrayPoly.add(poly);
   }

   public void setFontOption(String str, boolean tf) {
      switch (str) {
      case "Serif":
         fontType = "Serif";
         break;
      case "Monospaced":
         fontType = "Monospaced";
         break;
      case "SansSerif":
         fontType = "SansSerif";
         break;
      case "Bold":
         if (tf)
            font_Bold = true;
         else
            font_Bold = false;
         break;
      case "Italic":
         if (tf)
            font_Italic = true;
         else
            font_Italic = false;
         break;
      }
   }
}