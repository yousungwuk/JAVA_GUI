package TeamProject;
//���� �� �ƹ���
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.io.Serializable;

public abstract class Inter_Poly implements Serializable, Cloneable{
   protected Point StartPoint; //��ŸƮ ����Ʈ(���콺)
   protected Point EndPoint;   //���� ����Ʈ(���콺)
   protected Point rStartPoint; //��ŸƮ ����Ʈ(���� ����)
   protected Point rEndPoint; //���� ����Ʈ(���� ����)
   protected int width;
   protected int height;
   protected int diameter;
   protected Color p_Color; //�� ����
   protected float lineType_width = 1; //���� �β�
   protected int lineType_cap = BasicStroke.CAP_ROUND; //�� ���� ���
   protected int lineType_join = BasicStroke.JOIN_ROUND; //�������� ���
   protected float lineType_miterlimit = 0; //������ ������ �Ѱ� (1 �̻� ��)
   protected float lineType_dash[] = {1,0}; //������ ���� ���� ���
   protected float lineType_dash_phase = 0;   //�������� ���� �Ÿ�
   protected boolean fill;
   protected boolean regular;
   protected boolean Done_set = false;
   
   public void setStartPoint(Point p) {
      StartPoint = p;
   }  
   public void setEndPoint(Point p) {
      EndPoint = p;
    }
   public void setRStartPoint(Point p) {
      rStartPoint = p;
   }
   public void setrEndPoint(Point p) {
      rEndPoint = p;
   }
   public void rEndPoint_HW() {
      height = rEndPoint.y - rStartPoint.y;
      width = rEndPoint.x - rStartPoint.x;
      if (regular) diameter = width;
   }
   public void HW_rEndPoint() {
      rEndPoint = new Point(rStartPoint.x+width, rStartPoint.y+height);
   }
   public void setColor(Color c) {
      p_Color = c;
   }
   public void setLineType_width(float stroke) {
      lineType_width = stroke;
   }
   public void setFillRegular(boolean f, boolean r) {
      fill = f;
      regular = r;
   }
   public Point getStartPoint() {
      return StartPoint;
   }
   public Point getEP() {
      return EndPoint;
   }
   public Point getRStartPoint() {
      return rStartPoint;
   }
   public Point getrEndPoint() {
      return rEndPoint;
   }
   public int getHeight() {
      return height;
   }
   public int getWidth() {
      return width;
   }
   public boolean contains(Point p) {
      if (rStartPoint.x <= p.x && rStartPoint.y <= p.y &&
            rEndPoint.x >= p.x && rEndPoint.y >= p.y) {
         return true;
      }
      return false;
   }
   public void drawBound(Graphics2D g2d,Color c) {
      g2d.setColor(c);
       final float dash[] = {2, 2};//�׸��� ������������ �Ÿ� ����˰��־� ���࿡ �� �׸��� graphics2d ���ٰ� ���������������� �׳� 
       g2d.setStroke(new BasicStroke(2,BasicStroke.CAP_BUTT,BasicStroke.JOIN_BEVEL,0,dash,0));
       g2d.drawRect(rStartPoint.x, rStartPoint.y, width, height);
   }
   public void drawSetPoint(Graphics2D g2d) {
      try {
         g2d.setStroke(new BasicStroke(2));
         List<Rectangle2D> pointArray = new ArrayList<Rectangle2D>();   
         Rectangle2D pNW = new Rectangle2D.Double(rStartPoint.x - 3, rStartPoint.y - 3, 6, 6);
         Rectangle2D pN = new Rectangle2D.Double(rStartPoint.x+(width/2)-3, rStartPoint.y - 3, 6, 6);
         Rectangle2D pNE = new Rectangle2D.Double(rEndPoint.x - 3, rStartPoint.y - 3, 6, 6);
         Rectangle2D pE = new Rectangle2D.Double(rEndPoint.x - 3, rStartPoint.y+(height/2) - 3, 6, 6);
         Rectangle2D pSE = new Rectangle2D.Double(rEndPoint.x - 3, rEndPoint.y - 3, 6, 6);
         Rectangle2D pS = new Rectangle2D.Double(rStartPoint.x+(width/2)-3, rEndPoint.y - 3, 6, 6);
         Rectangle2D pSW = new Rectangle2D.Double(rStartPoint.x - 3, rEndPoint.y - 3, 6, 6);
         Rectangle2D pW = new Rectangle2D.Double(rStartPoint.x - 3, rStartPoint.y+(height/2) - 3, 6, 6);
         
         pointArray.add(pNW);
         pointArray.add(pN);
         pointArray.add(pNE);
         pointArray.add(pE);
         pointArray.add(pSE);
         pointArray.add(pS);
         pointArray.add(pSW);
         pointArray.add(pW);
         
         for (Rectangle2D i : pointArray) {
            g2d.setPaint(Color.WHITE);
              g2d.fill(i);
              g2d.setPaint(Color.BLACK);
              g2d.draw(i);
         }
       }
       catch (NullPointerException e){
          //System.err.println("�����Ͱ� �Էµ��� ����");
       }
   }
   public int getMoveCursor(Point e) {
      Rectangle2D pNW = new Rectangle2D.Double(rStartPoint.x - 3, rStartPoint.y - 3, 6, 6);
      Rectangle2D pN = new Rectangle2D.Double(rStartPoint.x+(width/2)-3, rStartPoint.y - 3, 6, 6);
      Rectangle2D pNE = new Rectangle2D.Double(rEndPoint.x - 3, rStartPoint.y - 3, 6, 6);
      Rectangle2D pE = new Rectangle2D.Double(rEndPoint.x - 3, rStartPoint.y+(height/2) - 3, 6, 6);
      Rectangle2D pSE = new Rectangle2D.Double(rEndPoint.x - 3, rEndPoint.y - 3, 6, 6);
      Rectangle2D pS = new Rectangle2D.Double(rStartPoint.x+(width/2)-3, rEndPoint.y - 3, 6, 6);
      Rectangle2D pSW = new Rectangle2D.Double(rStartPoint.x - 3, rEndPoint.y - 3, 6, 6);
      Rectangle2D pW = new Rectangle2D.Double(rStartPoint.x - 3, rStartPoint.y+(height/2) - 3, 6, 6);
      
      if (pNW.contains(e)) {
            return Cursor.NW_RESIZE_CURSOR;
        }
      else if (pN.contains(e)) {
            return Cursor.N_RESIZE_CURSOR;
        }
      else if (pNE.contains(e)) {
            return Cursor.NE_RESIZE_CURSOR;
        }
      else if (pE.contains(e)) {
            return Cursor.E_RESIZE_CURSOR;
        }
      else if (pSE.contains(e)) {
            return Cursor.SE_RESIZE_CURSOR;
        }
      else if (pS.contains(e)) {
            return Cursor.S_RESIZE_CURSOR;
        }
      else if (pSW.contains(e)) {
            return Cursor.SW_RESIZE_CURSOR;
        }
      else if (pW.contains(e)) {
            return Cursor.W_RESIZE_CURSOR;
        }
      else return Cursor.DEFAULT_CURSOR;
   }
   public String polyMove(Point e) {
      Rectangle2D pNW = new Rectangle2D.Double(rStartPoint.x - 3, rStartPoint.y - 3, 6, 6);
      Rectangle2D pN = new Rectangle2D.Double(rStartPoint.x+(width/2)-3, rStartPoint.y - 3, 6, 6);
      Rectangle2D pNE = new Rectangle2D.Double(rEndPoint.x - 3, rStartPoint.y - 3, 6, 6);
      Rectangle2D pE = new Rectangle2D.Double(rEndPoint.x - 3, rStartPoint.y+(height/2) - 3, 6, 6);
      Rectangle2D pSE = new Rectangle2D.Double(rEndPoint.x - 3, rEndPoint.y - 3, 6, 6);
      Rectangle2D pS = new Rectangle2D.Double(rStartPoint.x+(width/2)-3, rEndPoint.y - 3, 6, 6);
      Rectangle2D pSW = new Rectangle2D.Double(rStartPoint.x - 3, rEndPoint.y - 3, 6, 6);
      Rectangle2D pW = new Rectangle2D.Double(rStartPoint.x - 3, rStartPoint.y+(height/2) - 3, 6, 6);
      
      if (pNW.contains(e)) {
            return "pNW";
        }
      else if (pN.contains(e)) {
            return "pN";
        }
      else if (pNE.contains(e)) {
            return "pNE";
        }
      else if (pE.contains(e)) {
            return "pE";
        }
      else if (pSE.contains(e)) {
            return "pSE";
        }
      else if (pS.contains(e)) {
            return "pS";
        }
      else if (pSW.contains(e)) {
            return "pSW";
        }
      else if (pW.contains(e)) {
            return "pW";
        }
      else if(contains(e)) {
         return "move";
      }
      else return "";
   }
   public void setOptimization(boolean tf) {
      Done_set = tf;
   }
   abstract void draw(Graphics2D g);
   
   @Override
   public Object clone() throws CloneNotSupportedException { //��ü �����
      Object obj=null;
      try {
         obj = super.clone();
      }
      catch(Exception e) {}
      return obj;
   }
}