package TeamProject;

import java.awt.Color;
import javax.swing.JColorChooser;

public class PaintTest {
	public static void main(String[] args) {
		PaintFrame pFrame = new PaintFrame();
	}
}
