package TeamProject;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.*;

public class Poly_FreeDraw extends Inter_Poly {
	private List<Integer> xList; // 
	private List<Integer> yList; // 

	// Constructor
	public Poly_FreeDraw() {
		xList = new ArrayList<Integer>();
		yList = new ArrayList<Integer>();
	}/*
		 * @Override public boolean contains(Point p) { return false; }
		 */

	@Override
	public void drawBound(Graphics2D g2d, Color c) {
		g2d.setColor(c);
		final float dash[] = { 2, 2 };
		g2d.setStroke(new BasicStroke(2, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, dash, 0));
		for (int i = 0; i < xList.size() - 1; ++i) {
			g2d.drawLine((int) xList.get(i), (int) yList.get(i), (int) xList.get(i + 1), (int) yList.get(i + 1));
		}
	}

	@Override
	public boolean contains(Point p) {
		for (int i = 0; i < xList.size() - 1; ++i) {
			int x1 = xList.get(i) - 10;
			int x2 = xList.get(i) + 10;
			int y1 = yList.get(i) - 10;
			int y2 = yList.get(i) + 10;
			if (x1 <= p.x && y1 <= p.y && x2 >= p.x && y2 >= p.y) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void draw(Graphics2D g) {
		lineType_cap = BasicStroke.CAP_ROUND;
		lineType_join = BasicStroke.JOIN_ROUND;
		BasicStroke lineType;
		lineType = new BasicStroke(lineType_width, lineType_cap, lineType_join, lineType_miterlimit, lineType_dash,
				lineType_dash_phase);
		g.setStroke(lineType);
		g.setColor(p_Color);
		xList.add(EndPoint.x);
		yList.add(EndPoint.y);
		for (int i = 0; i < xList.size() - 1; ++i) {
			g.drawLine((int) xList.get(i), (int) yList.get(i), (int) xList.get(i + 1), (int) yList.get(i + 1));
		}
	}
}