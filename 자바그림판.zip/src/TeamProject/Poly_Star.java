package TeamProject;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Point;

public class Poly_Star extends Inter_Poly{
	private int[] X;
	private int[] Y;
	@Override
	public void draw(Graphics2D g) {
		if (Done_set) {
			BasicStroke lineType;
			lineType = new BasicStroke(
					lineType_width,lineType_cap,
					lineType_join,lineType_miterlimit,
					lineType_dash,lineType_dash_phase);
			g.setStroke(lineType);
			g.setColor(p_Color);
			if (regular) {
				diameter = Math.min(Math.abs(rEndPoint.x - rStartPoint.x), Math.abs(rEndPoint.y - rStartPoint.y));
				X = new int[] {rStartPoint.x, rStartPoint.x+(int)(diameter*0.3), rStartPoint.x+diameter/2, rEndPoint.x-(int)(diameter*0.3), rEndPoint.x,
						rEndPoint.x-(int)(diameter*0.3), rEndPoint.x-(int)(diameter*0.2), rStartPoint.x+diameter/2, rStartPoint.x+(int)(diameter*0.2),
						rStartPoint.x+(int)(diameter*0.3)};
				Y = new int[] {rStartPoint.y+(int)(diameter*0.4), rStartPoint.y+(int)(diameter*0.4), rStartPoint.y, rStartPoint.y+(int)(diameter*0.4), rStartPoint.y+(int)(diameter*0.4),
						rStartPoint.y+(int)(diameter*0.7), rEndPoint.y, rStartPoint.y+(int)(diameter*0.8), rEndPoint.y,
						rStartPoint.y+(int)(diameter*0.7)};
				if (fill) {
					g.fillPolygon(X, Y, 10);
				}
				else {
					g.drawPolygon(X, Y, 10);
				}
			}
			else {
				X = new int[] {rStartPoint.x, rStartPoint.x+(int)(width*0.3), rStartPoint.x+width/2, rEndPoint.x-(int)(width*0.3), rEndPoint.x,
						rEndPoint.x-(int)(width*0.3), rEndPoint.x-(int)(width*0.2), rStartPoint.x+width/2, rStartPoint.x+(int)(width*0.2), rStartPoint.x+(int)(width*0.3)};
				Y = new int[] {rStartPoint.y+(int)(height*0.4), rStartPoint.y+(int)(height*0.4), rStartPoint.y, rStartPoint.y+(int)(height*0.4), rStartPoint.y+(int)(height*0.4),
						rStartPoint.y+(int)(height*0.7), rEndPoint.y, rStartPoint.y+(int)(height*0.8), rEndPoint.y, rStartPoint.y+(int)(height*0.7)};
				if (fill) {
					g.fillPolygon(X, Y, 10);
				}
				else {
					g.drawPolygon(X, Y, 10);
				} 
			}
			return;
		}
		BasicStroke lineType;
		lineType = new BasicStroke(
				lineType_width,lineType_cap,
				lineType_join,lineType_miterlimit,
				lineType_dash,lineType_dash_phase);
		g.setStroke(lineType);
		g.setColor(p_Color);
		//
		if (regular) {
			diameter = Math.min(Math.abs(EndPoint.x - StartPoint.x), Math.abs(EndPoint.y - StartPoint.y));
			width = diameter;
			height = diameter;
			int xDiameter = diameter;
			int yDiameter = diameter;
			if (EndPoint.x < StartPoint.x) xDiameter *= -1;
			if (EndPoint.y < StartPoint.y) yDiameter *= -1;
			rStartPoint = new Point(Math.min(StartPoint.x, StartPoint.x+xDiameter), Math.min(StartPoint.y, StartPoint.y+yDiameter));
			rEndPoint = new Point(rStartPoint.x+diameter, rStartPoint.y+diameter);
			X = new int[] {rStartPoint.x, rStartPoint.x+(int)(diameter*0.3), rStartPoint.x+diameter/2, rEndPoint.x-(int)(diameter*0.3), rEndPoint.x,
					rEndPoint.x-(int)(diameter*0.3), rEndPoint.x-(int)(diameter*0.2), rStartPoint.x+diameter/2, rStartPoint.x+(int)(diameter*0.2),
					rStartPoint.x+(int)(diameter*0.3)};
			Y = new int[] {rStartPoint.y+(int)(diameter*0.4), rStartPoint.y+(int)(diameter*0.4), rStartPoint.y, rStartPoint.y+(int)(diameter*0.4), rStartPoint.y+(int)(diameter*0.4),
					rStartPoint.y+(int)(diameter*0.7), rEndPoint.y, rStartPoint.y+(int)(diameter*0.8), rEndPoint.y,
					rStartPoint.y+(int)(diameter*0.7)};
			if (fill) {
				g.fillPolygon(X, Y, 10);
			}
			else {
				g.drawPolygon(X, Y, 10);
			}
		}
		else {
			width = Math.abs(EndPoint.x - StartPoint.x);
			height = Math.abs(EndPoint.y - StartPoint.y);
			rStartPoint = new Point(Math.min(StartPoint.x, EndPoint.x), Math.min(StartPoint.y, EndPoint.y));
			rEndPoint = new Point(rStartPoint.x+width, rStartPoint.y+height);
			X = new int[] {rStartPoint.x, rStartPoint.x+(int)(width*0.3), rStartPoint.x+width/2, rEndPoint.x-(int)(width*0.3), rEndPoint.x,
					rEndPoint.x-(int)(width*0.3), rEndPoint.x-(int)(width*0.2), rStartPoint.x+width/2, rStartPoint.x+(int)(width*0.2), rStartPoint.x+(int)(width*0.3)};
			Y = new int[] {rStartPoint.y+(int)(height*0.4), rStartPoint.y+(int)(height*0.4), rStartPoint.y, rStartPoint.y+(int)(height*0.4), rStartPoint.y+(int)(height*0.4),
					rStartPoint.y+(int)(height*0.7), rEndPoint.y, rStartPoint.y+(int)(height*0.8), rEndPoint.y, rStartPoint.y+(int)(height*0.7)};
			if (fill) {
				g.fillPolygon(X, Y, 10);
			}
			else {
				g.drawPolygon(X, Y, 10);
			} 
		}
	}
}
