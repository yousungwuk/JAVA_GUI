package TeamProject;
import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

public class Poly_Line extends Inter_Poly
{
   @Override
   public void draw(Graphics2D g) {
	   BasicStroke lineType;
	   lineType = new BasicStroke(
				  	lineType_width,lineType_cap,
					lineType_join,lineType_miterlimit,
					lineType_dash,lineType_dash_phase);
	   g.setStroke(lineType);
	   g.setColor(p_Color);
	   rStartPoint = StartPoint;
	   rEndPoint = EndPoint;
	   if (regular) {
		   g.drawLine(rStartPoint.x, rStartPoint.y, EndPoint.x, EndPoint.y);
	   }
	   else {
		   rEndPoint = EndPoint;
		   width = Math.abs(EndPoint.x - StartPoint.x);
		   height = Math.abs(EndPoint.y - StartPoint.y);
		   g.drawLine(rStartPoint.x, rStartPoint.y, rEndPoint.x, rEndPoint.y);
	   }	   
   }
}