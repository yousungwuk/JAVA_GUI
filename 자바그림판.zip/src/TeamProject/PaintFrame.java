package TeamProject;
//frame�̶� �޴�����ִ¾�
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PaintFrame extends JFrame {
   private PaintPanel panel;
   private ObjectOutputStream output;
   private ObjectInputStream input;
   private JCheckBoxMenuItem[] toolCheckMenuItem;
   private JCheckBoxMenuItem[] fontCheckMenuItem;
   private JFileChooser chooser;
   private Color precolor=Color.black;
   public PaintFrame() {
      super("����,����,����-�׸���"); // â ���� ����
      createMenu(); // �޴��� ����
      setSize(500, 500); // â ũ�� ����
      panel = new PaintPanel(); // PaintPanel ����
      add(panel, BorderLayout.CENTER); // Frame�� Panel ��ġ
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//
      Image icon = new ImageIcon("painticon.png").getImage();
      this.setIconImage(icon);
      chooser = new JFileChooser();
      // â�� �߾ӿ� ��ġ�Ѵ�.
      Dimension scrnSize = Toolkit.getDefaultToolkit().getScreenSize();//����ũ�� ������ �ؼ� �߰��� ���� ���ִ� �Լ�
      int scrnWidth = getSize().width;
      int scrnHeight = getSize().height;
      int x = (scrnSize.width - scrnWidth) / 2;
      int y = (scrnSize.height - scrnHeight) / 2;
      // â�� �߾����� �ű��.
      setLocation(x, y);
      setVisible(true);// â ����
   }

   private void createMenu() {
      PaintMenuBar menubar = new PaintMenuBar();
      setJMenuBar(menubar);
   }

   private class PaintMenuBar extends JMenuBar {
      public PaintMenuBar() {
         // Ȩ �޴� ����
         String[] fileItemTitle = { "New", "Open", "Save", "OpenPicture", "Exit" };
         JMenu fileMenu = new JMenu("File(F)");
         fileMenu.setMnemonic('F'); // ����Ű
         JMenuItem[] fileMenuItem = new JMenuItem[fileItemTitle.length];
         MenuActionListener listener = new MenuActionListener();
         MenuItemListener itemListener = new MenuItemListener();
         for (int i = 0; i < fileMenuItem.length; i++) {
            fileMenuItem[i] = new JMenuItem(fileItemTitle[i]);
            fileMenuItem[i].addActionListener(listener);
            fileMenu.add(fileMenuItem[i]);
         }
         add(fileMenu);
         // Ȩ �޴� ��
         // �÷� �޴� ����
         String[] colorItemTitle = { "Black","���찳", "White", "Red", "Yellow", "Green", "Blue", "More Color" };
         Color[] colorItemColor = { Color.BLACK,Color.black, Color.WHITE, Color.RED, Color.YELLOW, Color.GREEN, Color.BLUE,
               Color.BLACK };
         JMenu colorMenu = new JMenu("Color(C)");
         colorMenu.setMnemonic('C');
         JMenuItem[] colorMenuItem = new JMenuItem[colorItemTitle.length];
         for (int i = 0; i < colorMenuItem.length; i++) {
            colorMenuItem[i] = new JMenuItem(colorItemTitle[i]);
            colorMenuItem[i].addActionListener(listener);
            colorMenuItem[i].setForeground(colorItemColor[i]);
            colorMenu.add(colorMenuItem[i]);
         }
         add(colorMenu);
         // �÷� �޴� ��
         // �� ���� �޴� ����
         String[] strokeItem = { "1", "2", "3", "4", "More" };
         JMenu strokeMenu = new JMenu("Stroke(S)");
         strokeMenu.setMnemonic('S');
         JMenuItem[] strokeMenuItem = new JMenuItem[strokeItem.length];
         for (int i = 0; i < strokeMenuItem.length; i++) {
            strokeMenuItem[i] = new JMenuItem(strokeItem[i]);
            strokeMenuItem[i].addActionListener(listener);
            strokeMenu.add(strokeMenuItem[i]);
         }
         add(strokeMenu);
         // �� ���� �޴� ��
         // ���� �޴� ����
         String[] polyItem = { "������", "��", "�簢��", "��", "�ﰢ��", "�����ﰢ��", "��", "�ؽ�Ʈ" };
         JMenu polyMenu = new JMenu("Poly(P)");
         polyMenu.setMnemonic('P');
         JMenuItem[] polyMenuItem = new JMenuItem[polyItem.length];
         for (int i = 0; i < polyMenuItem.length; i++) {
            polyMenuItem[i] = new JMenuItem(polyItem[i]);
            polyMenuItem[i].addActionListener(listener);
            polyMenu.add(polyMenuItem[i]);
         }
         add(polyMenu);
         // ���� �޴� ��
         // �� �޴� ����
         JMenu toolMenu = new JMenu("Tool(T)");
         toolMenu.setMnemonic('T');
         String[] toolCheckItem = { "ä���", "���ٰ���" };
         toolCheckMenuItem = new JCheckBoxMenuItem[toolCheckItem.length];
         for (int i = 0; i < toolCheckMenuItem.length; i++) {
            toolCheckMenuItem[i] = new JCheckBoxMenuItem(toolCheckItem[i]);
            toolCheckMenuItem[i].addItemListener(itemListener);
            toolMenu.add(toolCheckMenuItem[i]);
         }
         toolMenu.addSeparator();
         String[] toolItem = { "���� ����", "���� ����","���� ����" };
         JMenuItem[] toolMenuItem = new JMenuItem[toolItem.length];
         for (int i = 0; i < toolMenuItem.length; i++) {
            toolMenuItem[i] = new JMenuItem(toolItem[i]);
            toolMenuItem[i].addActionListener(listener);
            toolMenu.add(toolMenuItem[i]);
         }
         toolMenu.addSeparator();
         JMenu fontMenu = new JMenu("��Ʈ");
         String[] fontItem = { "Serif", "Monospaced", "SansSerif" };
         JMenuItem[] fontMenuItem = new JMenuItem[fontItem.length];
         for (int i = 0; i < fontMenuItem.length; i++) {
            fontMenuItem[i] = new JMenuItem(fontItem[i]);
            fontMenuItem[i].addActionListener(listener);
            fontMenu.add(fontMenuItem[i]);
         }
         fontMenu.addSeparator();
         String[] fontCheckItem = { "Bold", "Italic" };
         fontCheckMenuItem = new JCheckBoxMenuItem[fontCheckItem.length];
         for (int i = 0; i < fontCheckMenuItem.length; i++) {
            fontCheckMenuItem[i] = new JCheckBoxMenuItem(fontCheckItem[i]);
            fontCheckMenuItem[i].addItemListener(itemListener);
            fontMenu.add(fontCheckMenuItem[i]);
         }
         toolMenu.add(fontMenu);
         add(toolMenu);
         // �� �޴� ��
      }
   }

   private class MenuActionListener extends JFrame implements ActionListener {
      // field
      private JFileChooser chooser = new JFileChooser();
      // method
      @Override
      public void actionPerformed(ActionEvent e) {
         String cmd = e.getActionCommand();//�� �޴��̸� ��ȯ����
         switch (cmd) {
         case "New":
            panel.clearPanel();
            toolCheckMenuItem[0].setSelected(false);
            toolCheckMenuItem[1].setSelected(false);
            break;
         case "Open":
            int ret = chooser.showOpenDialog(null);
            if (ret != JFileChooser.APPROVE_OPTION) {
               JOptionPane.showMessageDialog(null, "No Select", "Error", JOptionPane.WARNING_MESSAGE);
               return;
            }
            String filePath = chooser.getSelectedFile().getPath();
            List<Inter_Poly> readArrayPoly = new ArrayList<Inter_Poly>();
            try {
               input = new ObjectInputStream(new FileInputStream(filePath));
            } catch (IOException e1) {
               System.err.println("Error opening file.");
               // e1.printStackTrace();
               return;
            }
            try {
               while (true) {
                  Inter_Poly poly;
                  poly = (Inter_Poly) input.readObject();
                  readArrayPoly.add(poly);
               }
            } catch (EOFException e2) {
               panel.setArrayPoly(readArrayPoly);
               panel.repaint();
               System.out.println("Open");
               return;
            } catch (ClassNotFoundException e3) {
               System.err.println("Unable to create object.");
               // e3.printStackTrace();
            } catch (IOException e4) {
               System.err.println("Error during read from file.");
               // e4.printStackTrace();
            }
            try {
               if (input != null)
                  input.close();
            } catch (IOException e5) {
               System.err.println("Error closing file.");
               // e5.printStackTrace();
               return;
            }
            break;
         case "Save":
            File savefile;
            String savepathname;
            int re = chooser.showSaveDialog(null);
            if (re == JFileChooser.APPROVE_OPTION) {
               savefile = chooser.getSelectedFile();
               savepathname = savefile.getAbsolutePath();
            } else {
               JOptionPane.showMessageDialog(null, "No Select", "Error", JOptionPane.WARNING_MESSAGE);
               return;
            }
            List<Inter_Poly> saveArrayPoly = new ArrayList<Inter_Poly>();
            saveArrayPoly = panel.getArrayPoly();
            try {
               output = new ObjectOutputStream(new FileOutputStream(savepathname));
            } catch (IOException ioException) {
               System.err.println("Error opening file.");
            }
            for (Inter_Poly poly : saveArrayPoly) {
               try {
                  output.writeObject(poly);
               } catch (IOException ioexception) {
                  System.err.println("Error writing to file.");
                  ioexception.printStackTrace();
                  return;
               }
            }
            try {
               if (output != null)
                  output.close();
            } catch (IOException ioException) {
               System.err.println("Error closing file");
               return;
            }
            System.out.println("Save");
            break;
         case "OpenPicture":
            int ret2 = chooser.showOpenDialog(null);
            if (ret2 != JFileChooser.APPROVE_OPTION) {
               JOptionPane.showMessageDialog(null, "No Select", "Error", JOptionPane.WARNING_MESSAGE);
               return;
            }
            String picturefilePath = chooser.getSelectedFile().getPath();
            panel.insertPoly(new Poly_Img(picturefilePath));
            panel.repaint();
            // System.out.println(img.getWidth(null));
            // System.out.println(img.getHeight(null));
            break;
         case "Exit":
            System.exit(0);
            break;
         
         case "Black":
            panel.setColor(Color.BLACK);
            precolor = Color.black;
            break;
         case "���찳":
            //Color precolor = precolor;
            panel.setColor(Color.WHITE);
            panel.setPoly("������");
            panel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            break;
         case "White":
            panel.setColor(Color.WHITE);
            break;
         case "Red":
            panel.setColor(Color.RED);
            precolor = Color.red;
            break;
         case "Blue":
            panel.setColor(Color.BLUE);
            precolor = Color.blue;
            break;
         case "Yellow":
            panel.setColor(Color.YELLOW);
            precolor = Color.yellow;
            break;
         case "Green":
            panel.setColor(Color.GREEN);
            precolor = Color.green;
            break;
         case "More Color":
            panel.setColor(precolor = JColorChooser.showDialog(null, "More Color", Color.BLACK));
            //precolor = Color.red;
            break;
         case "1":
            panel.setStroke(1);
            break;
         case "2":
            panel.setStroke(2);
            break;
         case "3":
            panel.setStroke(3);
            break;
         case "4":
            panel.setStroke(4);
            break;
         case "More":
            try {
               String str_stroke = JOptionPane.showInputDialog("Enter StokeSize.(1-50)");
               int int_stroke = Integer.parseInt(str_stroke);
               if (int_stroke < 1 || int_stroke > 50) {
                  JOptionPane.showMessageDialog(null, "Please input 1-50", "Error", JOptionPane.PLAIN_MESSAGE);
               }
               panel.setStroke(int_stroke);
            } catch (NumberFormatException numberFormatException) {
               JOptionPane.showMessageDialog(null, "Invalid Input!", "Error", JOptionPane.PLAIN_MESSAGE);
            }
            break;
         
         case "��":
            panel.setPoly("��");
            panel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            panel.setColor(precolor);
            break;
         case "�ﰢ��":
            panel.setPoly("�ﰢ��");//setpoly ��� �Լ��� panel ���ִµ� �̰� 
            panel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            panel.setColor(precolor);
            break;
         case "�����ﰢ��":
            panel.setPoly("�����ﰢ��");
            panel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            panel.setColor(precolor);
            break;
         case "�簢��":
            panel.setPoly("�簢��");
            panel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            panel.setColor(precolor);
            break;
         case "��":
            panel.setPoly("��");
            panel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            panel.setColor(precolor);
            break;
         case "������":
            panel.setPoly("������");
            panel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            panel.setColor(precolor);
            break;
         case "�ؽ�Ʈ":
            panel.setPoly("�ؽ�Ʈ");
            panel.setCursor(new Cursor(Cursor.TEXT_CURSOR));
            break;
         case "��":
            panel.setPoly("��");
            panel.setCursor(new Cursor(Cursor.CROSSHAIR_CURSOR));
            panel.setColor(precolor);
            break;
         case "���� ����":
            panel.setPoly("���� ����");
            panel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            toolCheckMenuItem[0].setSelected(false);
            toolCheckMenuItem[1].setSelected(false);
            break;
         case "���� ����":
            panel.setPoly("���� ����");
            panel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            toolCheckMenuItem[0].setSelected(false);
            toolCheckMenuItem[1].setSelected(false);
            break;
         case "���� ����":
            panel.setPoly("���� ����");
            panel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
            toolCheckMenuItem[0].setSelected(false);
            toolCheckMenuItem[1].setSelected(false);
            break;
         case "Serif":
            panel.setFontOption("Serif", true);
            break;
         case "Monospaced":
            panel.setFontOption("Monospaced", true);
            break;
         case "SansSerif":
            panel.setFontOption("SansSerif", true);
            break;
         default:
            break;
         }
      }
   }

   private class MenuItemListener implements ItemListener {
      @Override
      public void itemStateChanged(ItemEvent arg0) {
         if (toolCheckMenuItem[0].isSelected())
            panel.setOption("ä���", true);
         else
            panel.setOption("ä���", false);
         if (toolCheckMenuItem[1].isSelected())
            panel.setOption("���ٰ���", true);
         else
            panel.setOption("���ٰ���", false);
         if (fontCheckMenuItem[0].isSelected())
            panel.setFontOption("Bold", true);
         else
            panel.setOption("Bold", false);
         if (fontCheckMenuItem[1].isSelected())
            panel.setFontOption("Italic", true);
         else
            panel.setOption("Italic", false);
      }
   }
}